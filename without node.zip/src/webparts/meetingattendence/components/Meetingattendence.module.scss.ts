/* tslint:disable */
require("./Meetingattendence.module.css");
const styles = {
  meetingattendence: 'meetingattendence_772c7c43',
  teams: 'teams_772c7c43',
  welcome: 'welcome_772c7c43',
  welcomeImage: 'welcomeImage_772c7c43',
  links: 'links_772c7c43'
};

export default styles;
/* tslint:enable */