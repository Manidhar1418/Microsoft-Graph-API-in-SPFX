import * as React from 'react';
import type { IMeetingattendenceProps } from './IMeetingattendenceProps';
import "@pnp/sp/fields";
import "@pnp/sp/webs";
import "@pnp/sp/items";
import "@pnp/sp/folders";
import "@pnp/sp/lists";
import "@pnp/sp/site-groups/web";
import "@pnp/sp/files";
import "@pnp/sp/profiles";
import "@pnp/sp/site-groups";
export interface IButtonExampleProps {
    disabled?: boolean;
    checked?: boolean;
}
export default class Meetingattendence extends React.Component<IMeetingattendenceProps, {}> {
    private _peopplePicker;
    constructor(props: IMeetingattendenceProps);
    private _getPeoplePickerItems;
    render(): React.ReactElement<IMeetingattendenceProps>;
}
//# sourceMappingURL=Meetingattendence.d.ts.map