declare const styles: {
    meetingattendence: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Meetingattendence.module.scss.d.ts.map